﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Telegram.Bot;
using Telegram.Bot.Types;


using System.Text.Json;
using System.Text.Json.Serialization;
using System.IO;
using System.Net.NetworkInformation;


namespace teleWork
{


    public partial class Form1 : Form
    {
        public TelegramBot bot;
        
        



        public Form1()
        {
            InitializeComponent();
            bot = new TelegramBot("7589381788:AAEassgHyxA0ymZrjFgimp8pU-vsKEFQj10", UpdateUI);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            deserializzaReg();
            deserializzaAtt();
        }


        //spiegazione by griff.
        /*
            questo è un metodo che serve per aggiornare la text box con il messaggio ricevuto.
            if (InvokeRequired) -->controlla se il metodo è chiamatoda un altro thread.
            InvokeRequired --> è una proprietà di control.
            Invoke --> è un metodo di control che permette di eseguire un metodo in un thread diverso da quello che lo ha chiamato.
            Invoke(new Action(() => ...)) → Chiede alla UI di eseguire l'aggiornamento nel suo thread.
            
         */
        private void UpdateUI(string message)
        {
            if (InvokeRequired)
            {
                Invoke(new Action(() => lblReceivedMessage.Text = "Ultimo: " + message));
            }
            else
            {
                lblReceivedMessage.Text = "Ultimo: " + message;
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            bot.Start();
            lblStatus.Text = "Bot in esecuzione...";
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            bot.Stop();
            lblStatus.Text = "Bot fermato.";
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void deserializzaReg()
        {
            List<messaggioBot> mess = new List<messaggioBot>();

            string[] righe = File.ReadAllLines("registri.json");

            if (File.Exists("registri.json"))
            {
                foreach (string riga in righe)
                {
                    messaggioBot a = JsonSerializer.Deserialize<messaggioBot>(riga);
                    mess.Add(a);
                }
                bot.setMbotS(mess);

            }
        }

        private void deserializzaAtt()
        {
            string[] righe = File.ReadAllLines("attesa.json");

            if (File.Exists("attesa.json"))
            {
                foreach (string riga in righe)
                {
                    messaggioBot a = JsonSerializer.Deserialize<messaggioBot>(riga);
                    bot.aggAttesa(a);
                }
                

            }
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            string JsonString = string.Empty;
            string percorso = "registri.json";
            int cont = 0;
            List<messaggioBot> mess = bot.getMbotS();
            foreach (messaggioBot a in mess)
            {
                if (cont > 0)
                {
                    JsonString += Environment.NewLine;
                }

                JsonString += JsonSerializer.Serialize(a);
                cont++;
            }

            File.WriteAllText(percorso, JsonString);
        }


        





        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            Form2 Notifiche = new Form2(bot);
            Notifiche.ShowDialog();
        }

        
        private void flowM1(object sender, PaintEventArgs e)
        {

        }

        




    }

    













    public class messaggioBot 
        {
            
        
            private long UserId;
            private string UserName;
            private string UserText;
            private DateTime DataMessaggio;

            public messaggioBot(long userId, string userName, string userText, DateTime dataMessaggio)
            {
                UserId = userId;
                UserName = userName;
                UserText = userText;
                DataMessaggio = dataMessaggio;
            }
            public long userId
            {
                get { return UserId; }
                set { UserId = value; }
            }
            public string userName
            {
                get { return UserName; }
                set { UserName = value; }
            }
            public string userText
            {
                get { return UserText; }
                set { UserText = value; }
            }
            public DateTime dataMessaggio
            {
                get { return DataMessaggio; }
                set { DataMessaggio = value; }
            }
        }
        
        

    



        public class TelegramBot 
        {
        private List<messaggioBot> attesa = new List<messaggioBot>();
        public List<messaggioBot> MbotS = new List<messaggioBot>();
        private readonly ITelegramBotClient botClient;
            private Thread botThread;
            private bool isRunning = false;
            // telegram i messaggi li associa ad un id , quindi per non ricevere messaggi duplicati.
            private long lastUpdateId = 0;

            /* Il bot deve notificare alla Form quando riceve un nuovo messaggio.
               il bot gira su un thread separato, non può modificare direttamente l'interfaccia grafica 
               Action --> Definisce un delegato che rappresenta un metodo
             */
            private Action<string> onMessageReceived;
            private string lastReceivedMessage = "Nessun messaggio";

            public TelegramBot(string token, Action<string> updateUI)
            {
                botClient = new TelegramBotClient(token);
                // quando il bot riceve un messaggio, chiama il metodo updateUI.
                // si attacca al commento prima.
                onMessageReceived = updateUI;
            }

            public void Start()
            {
                if (isRunning) return;
                isRunning = true;
                botThread = new Thread(RunBot) { IsBackground = true };
                botThread.Start();
            }

            public void Stop()
            {
                isRunning = false;
                botThread?.Join();
            }

            private async void RunBot()
            {
            while (isRunning)
            {
                try
                {
                    var updates = await botClient.GetUpdatesAsync((int)(lastUpdateId + 1));

                    foreach (var update in updates)
                    {
                        if (update.Message == null) continue;
                        var message = update.Message;

                        if (message.Text == null) continue;

                        try
                        {
                            
                            messaggioBot TempM = new messaggioBot(message.Chat.Id, message.Chat.Username, message.Text, message.Date);
                            MbotS.Add(TempM);

                            lastReceivedMessage = message.Text;

                            
                            onMessageReceived?.Invoke(lastReceivedMessage);

                            aggAttesa(TempM);
                            await botClient.SendTextMessageAsync(message.Chat.Id, "Hai scritto: " + message.Text);

                            

                            lastUpdateId = update.Id;
                        }
                        catch (Exception ex)
                        {
                            
                            onMessageReceived?.Invoke("Errore nel messaggio: " + ex.Message);
                        }
                    }
                }
                catch (Exception ex)
                {
                    
                    onMessageReceived?.Invoke("Errore: " + ex.Message);
                }

                await Task.Delay(1000);
            }

        }

        public void aggAttesa(messaggioBot m)
        {
            attesa.Add(m);
            serial();
        }
        public void dAttesa(messaggioBot m)
        {
            attesa.Remove(m);
            serial();
        }
        public List<messaggioBot> getatt()
        {
            return attesa;
        }


        private void serial()
        {
            string JsonString = string.Empty;
            string percorso = "attesa.json";
            int cont = 0;
            
            foreach (messaggioBot a in attesa)
            {
                if (cont > 0)
                {
                    JsonString += Environment.NewLine;
                }

                JsonString += JsonSerializer.Serialize(a);
                cont++;
            }

            File.WriteAllText(percorso, JsonString);
        }

        

        public List<messaggioBot> getMbotS()
        {
            return MbotS;
        }
        public void setMbotS(List<messaggioBot> mess)
        {
            MbotS = mess;
        }
       

        }
    
    

   



}
