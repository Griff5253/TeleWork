﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace teleWork
{
    public partial class Form2 : Form
    {
        List<messaggioBot> attesa = new List<messaggioBot>();

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            attesa = Program.bot.getatt();
            string pathM = @"ImgRisorse\busta.jpg";

            foreach (messaggioBot a in attesa)
            {
                AggiungiMessaggio(a, pathM);
            }

            if(attesa.Count > 0)
            {
                label1.Visible = false;
            }
            else 
            {
                label1.Visible = true; 
            }
        }

        private void AggiungiMessaggio(messaggioBot messaggio, string imagePath)
        {
            FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
            {
                FlowDirection = FlowDirection.LeftToRight,
                Size = new Size(500, 100),
                BorderStyle = BorderStyle.FixedSingle,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Padding = new Padding(5),
                Tag = messaggio,
                BackColor = System.Drawing.Color.White

            };

            PictureBox picture = new PictureBox
            {
                Size = new Size(75, 65),
                Image = Image.FromFile(imagePath),
                SizeMode = PictureBoxSizeMode.Zoom,
                Margin = new Padding(5)
            };

            Label label = new Label
            {
                Text = messaggio.userText,
                Size = new Size(200, 65),
                BorderStyle = BorderStyle.FixedSingle,
                AutoSize = false,
                TextAlign = ContentAlignment.TopLeft,
                Margin = new Padding(5)
            };

            Panel buttonPanel = new Panel
            {
                Size = new Size(100, 65),
                Margin = new Padding(5)
            };

            Button bottone1 = new Button
            {
                Text = "Accetta",
                Size = new Size(100, 30),
                BackColor = Color.GreenYellow,
                Font = new Font("Calibri", 13, FontStyle.Bold),
                Dock = DockStyle.Top
            };
            bottone1.Click += Bottone_Click;

            Button bottone2 = new Button
            {
                Text = "Rifiuta",
                Font = new Font("Calibri", 13, FontStyle.Bold),
                Size = new Size(100, 30),
                BackColor = Color.OrangeRed,
                Dock = DockStyle.Bottom
            };
            bottone2.Click += Bottone2_Click;

            buttonPanel.Controls.Add(bottone2);
            buttonPanel.Controls.Add(bottone1);

            flowLayoutPanel.Controls.Add(picture);
            flowLayoutPanel.Controls.Add(label);
            flowLayoutPanel.Controls.Add(buttonPanel);

            flowLayoutPanel1.Controls.Add(flowLayoutPanel);
        }

        private void Bottone_Click(object sender, EventArgs e)
        {
            

            Button button = sender as Button;
            if (button != null)
            {
                FlowLayoutPanel panelToRemove = button.Parent.Parent as FlowLayoutPanel;
                if (panelToRemove != null && panelToRemove.Tag is messaggioBot messaggio)
                {
                    Program.bot.aggAccettato(messaggio);
                    Program.bot.dAttesa(messaggio);
                    attesa.Remove(messaggio);

                    flowLayoutPanel1.Controls.Remove(panelToRemove);
                    panelToRemove.Dispose();

                    if (attesa.Count > 0)
                    {
                        label1.Visible = false;
                    }
                    else
                    {
                        label1.Visible = true;
                    }

                }
            }
        }

        private void Bottone2_Click(object sender, EventArgs e)
        {
            Button button = sender as Button;
            if (button != null)
            {
                FlowLayoutPanel panelToRemove = button.Parent.Parent as FlowLayoutPanel;
                if (panelToRemove != null && panelToRemove.Tag is messaggioBot messaggio)
                {
                    Program.bot.dAttesa(messaggio);
                    attesa.Remove(messaggio);

                    flowLayoutPanel1.Controls.Remove(panelToRemove);
                    panelToRemove.Dispose();

                    if (attesa.Count > 0)
                    {
                        label1.Visible = false;
                    }
                    else
                    {
                        label1.Visible = true;
                    }
                }
            }
        }

       
    }
}
