﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace teleWork
{
    public partial class Form2 : Form
    {
        List<messaggioBot> attesa = new List<messaggioBot>();

        public Form2(TelegramBot bot)
        {
            InitializeComponent();
            attesa = bot.getatt();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            int i = 0;
            string pathM = @"ImgRisorse\busta.jpg";

            foreach (messaggioBot a in attesa)
            {
                
                FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
                {
                    FlowDirection = FlowDirection.LeftToRight, 
                    Name = i.ToString(),
                    Size = new Size(500, 100),
                    BorderStyle = BorderStyle.FixedSingle,
                    AutoSize = true,
                    AutoSizeMode = AutoSizeMode.GrowAndShrink,
                    Padding = new Padding(5)
                };

                
                PictureBox picture = new PictureBox
                {
                    Name = i.ToString(),
                    Size = new Size(75, 65),
                    Image = Image.FromFile(pathM),
                    SizeMode = PictureBoxSizeMode.Zoom,
                    Margin = new Padding(5)
                };

               
                Label label = new Label
                {
                    Text = a.userText,
                    Size = new Size(200, 65),
                    BorderStyle = BorderStyle.FixedSingle,
                    AutoSize = false,
                    TextAlign = ContentAlignment.MiddleLeft,
                    Margin = new Padding(5)
                };

                
                Panel buttonPanel = new Panel
                {
                    Size = new Size(100, 65),
                    Margin = new Padding(5)
                };

                
                Button bottone1 = new Button
                {
                    Text = "Acetta",
                    Name = i.ToString()+ "_accetta",
                    Size = new Size(100, 30),
                    BackColor = Color.GreenYellow,
                    Font = new Font("Calibri", 13, FontStyle.Bold),
                    Dock = DockStyle.Top 
                };

                bottone1.Click += Bottone_Click;

             
                Button bottone2 = new Button
                {
                    Text = "Rifiuta",
                    Font = new Font("Calibri", 13,FontStyle.Bold),

                    
                    Name = i.ToString() + "_rifiuta",
                    Size = new Size(100, 30),
                    BackColor = Color.OrangeRed,
                    Dock = DockStyle.Bottom 
                };

                bottone2.Click += Bottone2_Click;

           
                buttonPanel.Controls.Add(bottone2);
                buttonPanel.Controls.Add(bottone1);

               
                flowLayoutPanel.Controls.Add(picture);
                flowLayoutPanel.Controls.Add(label);
                flowLayoutPanel.Controls.Add(buttonPanel); 

                
                flowLayoutPanel1.Controls.Add(flowLayoutPanel);

                i++;
            }
        }

        private void Bottone_Click(object sender, EventArgs e)
        {
            
        }

        private void Bottone2_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            MessageBox.Show($"Secondo bottone cliccato: {button.Name}");
        }
    }
}
