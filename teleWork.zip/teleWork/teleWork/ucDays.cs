﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace teleWork
{
    public partial class ucDays : UserControl
    {
        string _day, date, weekday;
        int anno_mese_giorno;
        int anno_mese_giorno_oggi;
        JCalendario jCa = new JCalendario();

        private void panel1_Click(object sender, EventArgs e)
        {
            

            if(checkBox1.Checked == false && label1.Text != "" && anno_mese_giorno >= anno_mese_giorno_oggi )
            {
                checkBox1.Checked = true;
                if(Program.calendario.Gcol() != "null" && Program.calendario.GText() != "")
                {
                    Color col = ColorTranslator.FromHtml(Program.calendario.Gcol());
                    label2.Text = Program.calendario.GText();
                    this.BackColor = col;
                    jCa.data = date;
                    jCa.colore = Program.calendario.Gcol();
                    jCa.testo = Program.calendario.GText();
                    Program.calendario.Cadd(jCa);
                    Program.calendario.SHBS(1);


                }
                else
                {
                    jCa.data = date;
                    jCa.colore = Program.calendario.Gcol();
                    jCa.testo = Program.calendario.GText();
                    this.BackColor = Color.FromArgb(255,149, 69);
                    Program.calendario.SHBS(0);
                    Program.calendario.Cdel(jCa);
                    label2.Text = "";
                }
                
            }
            else
            {
                label2.Text = "";
                Program.calendario.Cdel(jCa);
                checkBox1.Checked = false;
                this.BackColor = Color.White;
            }
        }

        public ucDays(string day)
        {
            InitializeComponent();
            _day = day;
            label1.Text = day;

            checkBox1.Hide();
            date = Calendario._month + "/" + day + "/" + Calendario._year;
        }
             
         

        private void ucDays_Load(object sender, EventArgs e)
        {
            List<JCalendario> jCalendario = Program.calendario.Cget();
            anno_mese_giorno = int.Parse(Calendario._year.ToString() + Calendario._month.ToString() + _day);
            anno_mese_giorno_oggi = int.Parse(DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Day.ToString());
            if (label1.Text != "")
            {
                panel1.Cursor = Cursors.Hand;
            }
            if (anno_mese_giorno < anno_mese_giorno_oggi)
            {
                panel1.Cursor = Cursors.Default;
                this.BackColor = Color.FromArgb(255, 255, 255);
                label1.ForeColor = Color.FromArgb(0, 0, 0);
            }
            foreach (JCalendario a in jCalendario)
            {
                if (a.data == date)
                {
                    checkBox1.Checked = true;
                    label2.Text = a.testo;
                    this.BackColor = ColorTranslator.FromHtml(a.colore);
                 
                    
                    Program.calendario.SHBS(1);
                }
            }
        }
    }
}
