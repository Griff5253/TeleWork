﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace teleWork
{
    public partial class Calendario: Form
    {
        public static int _year, _month;
        private static List<JCalendario> jCalendario = new List<JCalendario>();
        public Calendario()
        {
            InitializeComponent();
        }

        private void Calendario_Load(object sender, EventArgs e)
        {
            showDays(DateTime.Now.Month, DateTime.Now.Year);
           
            deserializzaCa();

        }


        private void deserializzaCa()
        {
            string[] righe = File.ReadAllLines("calendario.json");

            if (File.Exists("calendario.json"))
            {
                foreach (string riga in righe)
                {
                    JCalendario a = JsonSerializer.Deserialize<JCalendario>(riga);
                    Cadd(a);
                }


            }

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            _month += 1;
            if (_month > 12)
            {
                _month = 1;
                _year += 1;
            }
            showDays(_month, _year);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            _month -= 1;
            if (_month < 1)
            {
                _month = 12;
                _year -= 1;
            }
            showDays(_month, _year);
        }

        private void showDays(int month, int year)
        {
           flowLayoutPanel1.Controls.Clear();
            _year = year;
            _month = month;
            string monthName = new DateTimeFormatInfo().GetMonthName(month);
            lbMonth.Text = monthName.ToUpper()+" " + year;
            DateTime startodTheMonth = new DateTime(year, month, 1);
            int day = DateTime.DaysInMonth(year, month);
            int week = Convert.ToInt32(startodTheMonth.DayOfWeek.ToString("d"))+1;
            for (int i = 1; i < week; i++)
            {
                ucDays uc = new ucDays("");
                flowLayoutPanel1.Controls.Add(uc);
            }
            for (int i = 1; i <= day; i++)
            {
                ucDays uc = new ucDays(i +"");
                flowLayoutPanel1.Controls.Add(uc);
            }
        }
        string[] check = {"c1","c2","c3","c4","c5","c6"};
        private void checkBox8_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            CheckBox clickedCheckBox = sender as CheckBox;
            foreach (string s in check)
            {
                if (s != clickedCheckBox.Name)
                {
                    CheckBox cb = this.Controls.Find(s, true).FirstOrDefault() as CheckBox;
                    if (cb != null)
                    {
                        cb.Checked = false;
                    }
                }
            }
            
        }
        public string Gcol()
        {
            foreach (string s in check)
            {
                CheckBox cb = this.Controls.Find(s, true).FirstOrDefault() as CheckBox;
                if (cb != null)
                {
                    if (cb.Checked)
                    {
                        return cb.ForeColor.Name;
                    }
                }
            }
            return "null";
        }
        public string GText() { 
            return textBox1.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string JsonString = string.Empty;
            string percorso = "calendario.json";
            int cont = 0;

            foreach (JCalendario a in jCalendario) 
            {
                if (cont > 0)
                {
                    JsonString += Environment.NewLine;
                }

                JsonString += JsonSerializer.Serialize(a);
                cont++;
            }

            File.WriteAllText(percorso, JsonString);

            button1.Visible = false;
        }

        public void SHBS(int v)
        {
            if(v== 1)
            {
                button1.Visible = true;
            }
            else
            {
                button1.Visible = false;
            }
           
        }

        public void Cadd(JCalendario j)
        {
            jCalendario.Add(j);
        }
        public void Cdel(JCalendario j)
        {
            jCalendario.Remove(j);
        }
        public List<JCalendario> Cget()
        {
            return jCalendario;
        }

    }
    

    public class JCalendario
    {
        public string data { get; set; }
        public string colore { get; set; }
        public string testo { get; set; }


       

    }

}
