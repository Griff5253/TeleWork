﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Telegram.Bot;
using Telegram.Bot.Types;


using System.Text.Json;
using System.Text.Json.Serialization;
using System.IO;
using System.Net.NetworkInformation;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
namespace teleWork
{


    public partial class Form1 : Form
    {
        
        
        



        public Form1()
        {
           
            InitializeComponent();
            Program.bot = new TelegramBot("7589381788:AAEassgHyxA0ymZrjFgimp8pU-vsKEFQj10", UpdateUI);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            deserializzaReg();
            deserializzaAtt();
            deserializzaacc();
            CaricaMessaggiUtenti();

        }



        //spiegazione by griff.
        /*
            questo è un metodo che serve per aggiornare la text box con il messaggio ricevuto.
            if (InvokeRequired) -->controlla se il metodo è chiamatoda un altro thread.
            InvokeRequired --> è una proprietà di control.
            Invoke --> è un metodo di control che permette di eseguire un metodo in un thread diverso da quello che lo ha chiamato.
            Invoke(new Action(() => ...)) → Chiede alla UI di eseguire l'aggiornamento nel suo thread.
            
         */
        private void UpdateUI(string message)
        {
          
        }
        public bool onoff = false;
        private void btnStart_Click(object sender, EventArgs e)
        {
            if (onoff == false)
            {
                Program.bot.Start();
                
                onoff = true;
                pictureBox2.Image = Image.FromFile("ImgRisorse/off.png");
            }
            else
            {
                Program.bot.Stop();
                
                onoff = false;
                pictureBox2.Image = Image.FromFile("ImgRisorse/on.png");
            }
        }
        

        public void AggiungiMessaggio(messaggioBot messaggio)
        {
            FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
            {
                FlowDirection = FlowDirection.LeftToRight,
                Size = new Size(300, 100),
                BorderStyle = BorderStyle.FixedSingle,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Padding = new Padding(5),
                Tag = messaggio,
                BackColor = System.Drawing.Color.White,
            };

            Panel panel = new Panel
            {
                Size = new Size(200, 90),
                Margin = new Padding(5)
            };

            Label label1 = new Label
            {
                Text = messaggio.userName,
                Size = new Size(200, 15),
                BorderStyle = BorderStyle.FixedSingle,
                AutoSize = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Margin = new Padding(5),
                Dock = DockStyle.Top
            };
            Label label2 = new Label
            {
                Text = messaggio.userText,
                Size = new Size(200, 75),
                BorderStyle = BorderStyle.None,
                AutoSize = false,
                TextAlign = ContentAlignment.TopLeft,
                Margin = new Padding(5),
                Dock = DockStyle.Bottom
            };
            Panel btnPanel = new Panel
            {
                Size = new Size(38, 30),
                Margin = new Padding(5),
                Dock = DockStyle.Right
            };
            System.Windows.Forms.Button bottone1 = new System.Windows.Forms.Button
            {
                Size = new Size(38, 30),
                Name = messaggio.userId.ToString(),
                BackColor = System.Drawing.Color.Transparent,
                Image = Image.FromFile("ImgRisorse/chat.png"),
                Dock = DockStyle.Right,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Cursor = Cursors.Hand
            };


            bottone1.Click += BtnChat;
            panel.Controls.Add(label1);
            panel.Controls.Add(label2);
            btnPanel.Controls.Add(bottone1);
            flowLayoutPanel.Controls.Add(panel);
            flowLayoutPanel.Controls.Add(btnPanel);
            flowLayoutPanel1.Controls.Add(flowLayoutPanel);
        }







        private void BtnChat(object sender, EventArgs e)
        {
            System.Windows.Forms.Button button = sender as System.Windows.Forms.Button;
            if (button != null)
            {
                string id = button.Name;
                FlChat(id);
            }
        }

        public long chatAttivaId = 0; 

        public void FlChat(string m)
        {
            chatAttivaId = Convert.ToInt64(m);
            long id = Convert.ToInt64(m);
            List<messaggioBot> messaggi = Program.bot.GetMessaggiUtente(id);
            flowLayoutPanel2.Controls.Clear();
            foreach (messaggioBot messaggio in messaggi)
            {
                FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
                {
                    FlowDirection =    messaggio.userName == "Server" ? FlowDirection.RightToLeft : FlowDirection.LeftToRight,
                    BorderStyle = BorderStyle.FixedSingle,
                    AutoSize = true,
                    AutoSizeMode = AutoSizeMode.GrowAndShrink,
                    Padding = new Padding(5),
                    Tag = m,
                    BackColor = messaggio.userName == "Server" ? System.Drawing.Color.LightBlue : System.Drawing.Color.White
                };
                    
                
                
               
               
                Label label2 = new Label
                {
                    BackColor = System.Drawing.Color.Transparent,
                    Text = messaggio.userText,
                    Size = new Size(370, 25),
                    BorderStyle = BorderStyle.None,
                    AutoSize = false,
                    TextAlign = messaggio.userName == "Server" ? ContentAlignment.TopRight : ContentAlignment.TopLeft,
                    Margin = new Padding(5),
                    Dock = DockStyle.Bottom
                };

                
                flowLayoutPanel.Controls.Add(label2);
                flowLayoutPanel2.Controls.Add(flowLayoutPanel);
               
            }
        

        }




        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void deserializzaReg()
        {
            List<messaggioBot> mess = new List<messaggioBot>();

            string[] righe = File.ReadAllLines("registri.json");

            if (File.Exists("registri.json"))
            {
                foreach (string riga in righe)
                {
                    messaggioBot a = JsonSerializer.Deserialize<messaggioBot>(riga);
                    mess.Add(a);
                }
                Program.bot.setMbotS(mess);

            }
        }

        private void deserializzaAtt()
        {
            string[] righe = File.ReadAllLines("attesa.json");

            if (File.Exists("attesa.json"))
            {
                foreach (string riga in righe)
                {
                    messaggioBot a = JsonSerializer.Deserialize<messaggioBot>(riga);
                    Program.bot.aggAttesa(a);
                }
                

            }
            
        }




        private void deserializzaacc()
        {
            string[] righe = File.ReadAllLines("accettato.json");

            if (File.Exists("accettato.json"))
            {
                foreach (string riga in righe)
                {
                    messaggioBot a = JsonSerializer.Deserialize<messaggioBot>(riga);
                    Program.bot.aggAccettato(a);
                }


            }

        }



        private void CaricaMessaggiUtenti()
        {
            string directory = "MessaggiUtenti";

            if (Directory.Exists(directory))
            {
                string[] files = Directory.GetFiles(directory, "messaggi_*.json");

                foreach (string file in files)
                {
                    try
                    {
                        string jsonString = File.ReadAllText(file);
                        List<messaggioBot> listaMessaggi = JsonSerializer.Deserialize<List<messaggioBot>>(jsonString);

                        if (listaMessaggi != null && listaMessaggi.Count > 0)
                        {
                            long userId = listaMessaggi[0].userId; 

                            Program.bot.messaggiUtente[userId] = listaMessaggi;
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Errore nel caricamento di {file}: {ex.Message}");
                    }
                }
            }
        }




        private void timer1_Tick(object sender, EventArgs e)
        {
            string JsonString = string.Empty;
            string percorso = "registri.json";
            int cont = 0;
            List<messaggioBot> mess = Program.bot.getMbotS();
            foreach (messaggioBot a in mess)
            {
                if (cont > 0)
                {
                    JsonString += Environment.NewLine;
                }

                JsonString += JsonSerializer.Serialize(a);
                cont++;
            }

            File.WriteAllText(percorso, JsonString);
        }


        





        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            Program.Notifiche= new Form2();
            Program.Notifiche.ShowDialog();
        }

        
        private void flowM1(object sender, PaintEventArgs e)
        {

        }

        private void btnInvio_Click(object sender, EventArgs e)
        {
            if (chatAttivaId == 0)
            {
                MessageBox.Show("Nessuna chat aperta.");
                return;
            }

            string testoMessaggio = textBox2.Text.Trim();
            if (string.IsNullOrEmpty(testoMessaggio))
            {
                MessageBox.Show("Inserisci un messaggio.");
                return;
            }


            messaggioBot nuovoMessaggio = new messaggioBot(chatAttivaId, "Server", testoMessaggio, DateTime.Now);

          
            Program.bot.GetMessaggiUtente(chatAttivaId).Add(nuovoMessaggio);
            

            Program.bot.scrivi(chatAttivaId, testoMessaggio);
            FlChat(chatAttivaId.ToString());

            
            textBox2.Clear();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Program.calendario = new Calendario();
            Program.calendario.ShowDialog();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            string url = "https://drive.google.com/drive/my-drive"; 
            try
            {
                Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Errore durante l'apertura della pagina: {ex.Message}");
            }
        }
    }















    public class messaggioBot 
        {
            
        
            private long UserId;
            private string UserName;
            private string UserText;
            private DateTime DataMessaggio;

            public messaggioBot(long userId, string userName, string userText, DateTime dataMessaggio)
            {
                UserId = userId;
                UserName = userName;
                UserText = userText;
                DataMessaggio = dataMessaggio;
            }
            public long userId
            {
                get { return UserId; }
                set { UserId = value; }
            }
            public string userName
            {
                get { return UserName; }
                set { UserName = value; }
            }
            public string userText
            {
                get { return UserText; }
                set { UserText = value; }
            }
            public DateTime dataMessaggio
            {
                get { return DataMessaggio; }
                set { DataMessaggio = value; }
            }
        }
        
        

    



        public class TelegramBot 
        {
        private List<messaggioBot> attesa = new List<messaggioBot>();
        public List<messaggioBot> MbotS = new List<messaggioBot>();
        private List<messaggioBot> accettato = new List<messaggioBot>();


        public Dictionary<long, List<messaggioBot>> messaggiUtente = new Dictionary<long, List<messaggioBot>>();

        private readonly ITelegramBotClient botClient;
            private Thread botThread;
            private bool isRunning = false;
            // telegram i messaggi li associa ad un id , quindi per non ricevere messaggi duplicati.
            private long lastUpdateId = 0;

            /* Il bot deve notificare alla Form quando riceve un nuovo messaggio.
               il bot gira su un thread separato, non può modificare direttamente l'interfaccia grafica 
               Action --> Definisce un delegato che rappresenta un metodo
             */
            private Action<string> onMessageReceived;
            private string lastReceivedMessage = "Nessun messaggio";

            public TelegramBot(string token, Action<string> updateUI)
            {
                botClient = new TelegramBotClient(token);
                // quando il bot riceve un messaggio, chiama il metodo updateUI.
                // si attacca al commento prima.
                onMessageReceived = updateUI;
            }

            public void Start()
            {
                if (isRunning) return;
                isRunning = true;
                botThread = new Thread(RunBot) { IsBackground = true };
                botThread.Start();
            }

            public void Stop()
            {
                isRunning = false;
                botThread?.Join();
            }

            private async void RunBot()
            {
            while (isRunning)
            {
                try
                {
                    var updates = await botClient.GetUpdatesAsync((int)(lastUpdateId + 1));
                    
                    foreach (var update in updates)
                    {
                        if (update.Message == null) continue;
                        var message = update.Message;

                        if (message.Text == null) continue;
                        
                        try
                        {
                            
                            messaggioBot TempM = new messaggioBot(message.Chat.Id, message.Chat.Username, message.Text, message.Date);

                            if (TempM.userText.StartsWith("/add"))
                            {
                                TempM.userText = TempM.userText.Substring(4).Trim();
                                MbotS.Add(TempM);

                                lastReceivedMessage = message.Text;


                                onMessageReceived?.Invoke(lastReceivedMessage);

                                aggAttesa(TempM);
                                


                                scrivi(TempM.userId, "Richiesta presa incarico");
                                lastUpdateId = update.Id;
                            }
                            else
                            {
                                if (!messaggiUtente.ContainsKey(TempM.userId))
                                {
                                    messaggiUtente[TempM.userId] = new List<messaggioBot>();
                                }

                               
                                messaggiUtente[TempM.userId].Add(TempM);
                                SalvaMessaggiUtente(TempM.userId);
                                lastUpdateId = update.Id;
                                if (Program.form1.chatAttivaId == TempM.userId)
                                {
                                    Program.form1.Invoke(new Action(() =>
                                    {
                                        Program.form1.FlChat(TempM.userId.ToString());
                                    }));
                                }
                            }
                            
                            
                        }
                        catch (Exception ex)
                        {
                            
                            onMessageReceived?.Invoke("Errore nel messaggio: " + ex.Message);
                        }
                    }
                }
                catch (Exception ex)
                {
                    
                    onMessageReceived?.Invoke("Errore: " + ex.Message);
                }

                await Task.Delay(1000);
            }

        }
        public async Task scrivi(long chatId, string message)
        {
            await Program.bot.botClient.SendTextMessageAsync(chatId, message);
            SalvaMessaggiUtente(chatId);
        }



        public List<messaggioBot> GetMessaggiUtente(long userId)
        {
            if (messaggiUtente.TryGetValue(userId, out List<messaggioBot> listaMessaggi))
            {
                return listaMessaggi;
            }
            return new List<messaggioBot>(); 
        }


        public void aggAttesa(messaggioBot m)
        {
            attesa.Add(m);
            serial();
            
        }
        public void dAttesa(messaggioBot m)
        {
            attesa.Remove(m);
            serial();
        }
        public List<messaggioBot> getatt()
        {
            return attesa;
        }


        public void aggAccettato(messaggioBot m)
        {
            accettato.Add(m);
           Program.form1.AggiungiMessaggio(m);
            serial2();

        }
        public void dAccettato(messaggioBot m)
        {
            accettato.Remove(m);
            serial2();
        }
        public List<messaggioBot> getAccettato()
        {
            return accettato;
        }






        private void SalvaMessaggiUtente(long userId)
        {
            string directory = "MessaggiUtenti";
            string filePath = Path.Combine(directory, $"messaggi_{userId}.json");

            // Creiamo la cartella se non esiste
            if (!Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }

            // Recuperiamo i messaggi dell'utente
            if (messaggiUtente.TryGetValue(userId, out List<messaggioBot> listaMessaggi))
            {
                // Convertiamo la lista in JSON
                string jsonString = JsonSerializer.Serialize(listaMessaggi, new JsonSerializerOptions { WriteIndented = true });

                // Salviamo il file
                File.WriteAllText(filePath, jsonString);
            }
        }







        private void serial()
        {
            string JsonString = string.Empty;
            string percorso = "attesa.json";
            int cont = 0;
            
            foreach (messaggioBot a in attesa)
            {
                if (cont > 0)
                {
                    JsonString += Environment.NewLine;
                }

                JsonString += JsonSerializer.Serialize(a);
                cont++;
            }

            File.WriteAllText(percorso, JsonString);
        }


        private void serial2()
        {
            string JsonString = string.Empty;
            string percorso = "accettato.json";
            int cont = 0;

            foreach (messaggioBot a in accettato)
            {
                if (cont > 0)
                {
                    JsonString += Environment.NewLine;
                }

                JsonString += JsonSerializer.Serialize(a);
                cont++;
            }

            File.WriteAllText(percorso, JsonString);
        }



        public List<messaggioBot> getMbotS()
        {
            return MbotS;
        }
        public void setMbotS(List<messaggioBot> mess)
        {
            MbotS = mess;
        }
       

        }
    
    

   



}
